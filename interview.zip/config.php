<?php  
    define("DB_HOST", 'localhost');  
    define("DB_USER", 'exampl56_exampl56');  
    define("DB_PASSWORD", 'SwK!]jtv=C)L');  
    define("DB_DATABSE", 'exampl56_programme');  
?>  




